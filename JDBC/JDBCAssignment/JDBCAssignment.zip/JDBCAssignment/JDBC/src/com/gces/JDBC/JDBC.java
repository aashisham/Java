package com.gces.JDBC;

import java.awt.*;
import java.sql.*;

public class JDBC extends Frame{
	
	public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String JDB_URL = "jdbc:mysql://localhost:3306/gces";
	
	String insertQuery;
	
	String name = "", address = "";
	
	Label nameLabel, messageLabel, addressLabel;
	Button clearButton, submitButton;
	TextField nameField, addressField;
	
	Input(String title) throws NullPointerException{
		super(title);
		
		setSize(300,400);
		setLayout(new FlowLayout());
		setVisible(true);
		
		messageLabel = new Label("Enter the details : ");
		
		clearButton = new Button("Clear");
		submitButton = new Button("Submit");
		
		nameField = new TextField("Name", 40);
		addressField = new TextField("Address", 40);

				
		add(messageLabel);
		add(nameField);
		add(addressField);
		
		add(clearButton);
		add(submitButton);
		
		nameField.addFocusListener(new FocusListener() {
			
			public void focusGained(FocusEvent fe) {
				if(nameField.getText().equals("Name")) {
					nameField.setText("");
				}				
			}
			
			public void focusLost(FocusEvent fe) {
				if(nameField.getText().equals("")) {
					nameField.setText("Name");
				}
			}
		});
		
		addressField.addFocusListener(new FocusListener() {
			
			public void focusGained(FocusEvent fe) {
				if(addressField.getText().equals("Address")) {
					addressField.setText("");
				}				
			}
			
			public void focusLost(FocusEvent fe) {
				if(addressField.getText().equals("")) {
					addressField.setText("Address");
				}
			}
		});
		
		
		clearButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent ae) {
				nameField.setText("Name");
				addressField.setText("Address");
			}
		});		
		
		addWindowListener(new WindowAdapter() {
			
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
		
		submitButton.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent ae) {
				if(!(nameField.getText().equals("Name") && addressField.getText().equals("Address") )) {
			
					try {
						insertQuery = "INSERT INTO `students` ( `username`, `address`)" + " VALUES (?, ?)";
						
						Class.forName(JDBC_DRIVER);
						Connection conn = DriverManager.getConnection(JDB_URL,"root","");
						PreparedStatement ps = conn.prepareStatement(insertQuery);
						ps.setString(1,nameField.getText());
						ps.setString(2, addressField.getText());
						ps.executeUpdate();
						ps.close();		
					}
					catch(SQLException e) {
						e.printStackTrace();
					}
					catch(ClassNotFoundException e) {
						e.printStackTrace();
					}					
				}
			}
		});	
	}
	
	public static void main(String[] args) {
		new JDBC("Data from form to Database");
	}
}